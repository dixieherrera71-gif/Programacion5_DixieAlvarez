﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE TABLE [Categorias] (
        [Id] int NOT NULL IDENTITY,
        [Nombre] nvarchar(60) NOT NULL,
        [Descripcion] nvarchar(200) NULL,
        [Activo] bit NOT NULL,
        CONSTRAINT [PK_Categorias] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE TABLE [Proveedores] (
        [Id] int NOT NULL IDENTITY,
        [Nombre] nvarchar(100) NOT NULL,
        [Telefono] nvarchar(20) NULL,
        [Correo] nvarchar(120) NULL,
        [Direccion] nvarchar(200) NULL,
        [Activo] bit NOT NULL,
        CONSTRAINT [PK_Proveedores] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE TABLE [Roles] (
        [Id] int NOT NULL IDENTITY,
        [NombreRol] nvarchar(30) NOT NULL,
        CONSTRAINT [PK_Roles] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE TABLE [Productos] (
        [Id] int NOT NULL IDENTITY,
        [Nombre] nvarchar(100) NOT NULL,
        [Descripcion] nvarchar(250) NULL,
        [Precio] decimal(10,2) NOT NULL,
        [Stock] int NOT NULL,
        [StockMinimo] int NOT NULL,
        [Activo] bit NOT NULL,
        [CategoriaId] int NOT NULL,
        [ProveedorId] int NOT NULL,
        CONSTRAINT [PK_Productos] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Productos_Categorias_CategoriaId] FOREIGN KEY ([CategoriaId]) REFERENCES [Categorias] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Productos_Proveedores_ProveedorId] FOREIGN KEY ([ProveedorId]) REFERENCES [Proveedores] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE TABLE [Usuarios] (
        [Id] int NOT NULL IDENTITY,
        [NombreUsuario] nvarchar(80) NOT NULL,
        [Correo] nvarchar(150) NOT NULL,
        [ContrasenaHash] nvarchar(500) NOT NULL,
        [Activo] bit NOT NULL,
        [RolId] int NOT NULL,
        CONSTRAINT [PK_Usuarios] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Usuarios_Roles_RolId] FOREIGN KEY ([RolId]) REFERENCES [Roles] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE TABLE [MovimientosInventario] (
        [Id] int NOT NULL IDENTITY,
        [TipoMovimiento] nvarchar(10) NOT NULL,
        [Cantidad] int NOT NULL,
        [Fecha] datetime2 NOT NULL,
        [Observacion] nvarchar(250) NULL,
        [ProductoId] int NOT NULL,
        CONSTRAINT [PK_MovimientosInventario] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_MovimientosInventario_Productos_ProductoId] FOREIGN KEY ([ProductoId]) REFERENCES [Productos] ([Id]) ON DELETE NO ACTION
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Activo', N'Descripcion', N'Nombre') AND [object_id] = OBJECT_ID(N'[Categorias]'))
        SET IDENTITY_INSERT [Categorias] ON;
    EXEC(N'INSERT INTO [Categorias] ([Id], [Activo], [Descripcion], [Nombre])
    VALUES (1, CAST(1 AS bit), N''Productos para el cuidado del rostro'', N''Cuidado facial''),
    (2, CAST(1 AS bit), N''Productos para el cuidado del cabello'', N''Cabello''),
    (3, CAST(1 AS bit), N''Productos de maquillaje'', N''Maquillaje''),
    (4, CAST(1 AS bit), N''Perfumes y fragancias'', N''Fragancias'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Activo', N'Descripcion', N'Nombre') AND [object_id] = OBJECT_ID(N'[Categorias]'))
        SET IDENTITY_INSERT [Categorias] OFF;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Activo', N'Correo', N'Direccion', N'Nombre', N'Telefono') AND [object_id] = OBJECT_ID(N'[Proveedores]'))
        SET IDENTITY_INSERT [Proveedores] ON;
    EXEC(N'INSERT INTO [Proveedores] ([Id], [Activo], [Correo], [Direccion], [Nombre], [Telefono])
    VALUES (1, CAST(1 AS bit), N''ventas@dermabelle.com'', NULL, N''Dermabelle'', N''2222-1111''),
    (2, CAST(1 AS bit), N''ventas@beautysupply.com'', NULL, N''Beauty Supply'', N''2222-2222''),
    (3, CAST(1 AS bit), N''ventas@glamcosmetics.com'', NULL, N''Glam Cosmetics'', N''2222-3333'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Activo', N'Correo', N'Direccion', N'Nombre', N'Telefono') AND [object_id] = OBJECT_ID(N'[Proveedores]'))
        SET IDENTITY_INSERT [Proveedores] OFF;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'NombreRol') AND [object_id] = OBJECT_ID(N'[Roles]'))
        SET IDENTITY_INSERT [Roles] ON;
    EXEC(N'INSERT INTO [Roles] ([Id], [NombreRol])
    VALUES (1, N''Administrador''),
    (2, N''Usuario'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'NombreRol') AND [object_id] = OBJECT_ID(N'[Roles]'))
        SET IDENTITY_INSERT [Roles] OFF;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Activo', N'CategoriaId', N'Descripcion', N'Nombre', N'Precio', N'ProveedorId', N'Stock', N'StockMinimo') AND [object_id] = OBJECT_ID(N'[Productos]'))
        SET IDENTITY_INSERT [Productos] ON;
    EXEC(N'INSERT INTO [Productos] ([Id], [Activo], [CategoriaId], [Descripcion], [Nombre], [Precio], [ProveedorId], [Stock], [StockMinimo])
    VALUES (1, CAST(1 AS bit), 1, N''Sérum facial'', N''Sérum vitamina C'', 18900.0, 1, 32, 10),
    (2, CAST(1 AS bit), 2, N''Shampoo para cabello seco'', N''Shampoo hidratante'', 7500.0, 2, 18, 10),
    (3, CAST(1 AS bit), 1, N''Protector solar facial'', N''Protector solar SPF 50'', 12900.0, 1, 9, 10),
    (4, CAST(1 AS bit), 3, N''Labial de acabado mate'', N''Labial mate'', 6500.0, 3, 14, 8)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Activo', N'CategoriaId', N'Descripcion', N'Nombre', N'Precio', N'ProveedorId', N'Stock', N'StockMinimo') AND [object_id] = OBJECT_ID(N'[Productos]'))
        SET IDENTITY_INSERT [Productos] OFF;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE INDEX [IX_MovimientosInventario_ProductoId] ON [MovimientosInventario] ([ProductoId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE INDEX [IX_Productos_CategoriaId] ON [Productos] ([CategoriaId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Productos_Nombre] ON [Productos] ([Nombre]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE INDEX [IX_Productos_ProveedorId] ON [Productos] ([ProveedorId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Roles_NombreRol] ON [Roles] ([NombreRol]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Usuarios_Correo] ON [Usuarios] ([Correo]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    CREATE INDEX [IX_Usuarios_RolId] ON [Usuarios] ([RolId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260818204305_Inicial'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260818204305_Inicial', N'10.0.10');
END;

COMMIT;
GO

