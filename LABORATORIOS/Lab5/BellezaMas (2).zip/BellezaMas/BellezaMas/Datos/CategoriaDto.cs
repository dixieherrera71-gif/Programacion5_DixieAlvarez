﻿namespace BellezaMas.Api.Dtos;

public class CategoriaDto
{
    public int Id { get; set; }

    public string Nombre { get; set; } = "";

    public string? Descripcion { get; set; }

    public bool Activo { get; set; }

    public int CantidadProductos { get; set; }
}