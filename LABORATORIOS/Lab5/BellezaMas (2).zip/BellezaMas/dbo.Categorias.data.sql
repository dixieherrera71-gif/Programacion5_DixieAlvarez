﻿SET IDENTITY_INSERT [dbo].[Categorias] ON
INSERT INTO [dbo].[Categorias] ([Id], [Nombre], [Descripcion], [Activo]) VALUES (1, N'Cuidado facial', N'Productos para el cuidado del rostro', 1)
INSERT INTO [dbo].[Categorias] ([Id], [Nombre], [Descripcion], [Activo]) VALUES (2, N'Cabello', N'Productos para el cuidado del cabello', 1)
INSERT INTO [dbo].[Categorias] ([Id], [Nombre], [Descripcion], [Activo]) VALUES (3, N'Maquillaje', N'Productos de maquillaje', 1)
INSERT INTO [dbo].[Categorias] ([Id], [Nombre], [Descripcion], [Activo]) VALUES (4, N'Fragancias', N'Perfumes y fragancias', 1)
SET IDENTITY_INSERT [dbo].[Categorias] OFF
